package common;

import dao.InventoryUtils;
import java.io.File;
import javax.swing.JOptionPane;

public class OpenPdf {

    public static void OpenById(String id) {
        try {
            File pdfFile = new File(InventoryUtils.billPath + id + ".pdf");

            if (pdfFile.exists()) {
                // This works on Windows
                Process p = Runtime.getRuntime().exec(
                        "rundll32 url.dll,FileProtocolHandler \"" + pdfFile.getAbsolutePath() + "\""
                );
            } else {
                JOptionPane.showMessageDialog(null, "File does not exist");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error opening PDF: " + e.getMessage());
        }
    }
}
