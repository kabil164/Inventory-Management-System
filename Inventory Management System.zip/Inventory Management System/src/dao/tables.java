/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author kabil
 */
public class tables {

    public static void main(String[] args) {

        Connection con = null;
        Statement st = null;
        try {
            con = ConnectionProvider.getCon();
            st = con.createStatement();
            // st.executeUpdate("CREATE TABLE appuser (appuser_pk int AUTO_INCREMENT primary key,userRole varchar(50),name varchar(200),mobileNumber varchar(50),email varchar(200),password varchar(50),address varchar (200),status varchar(50))");
            //  st.executeUpdate("insert into appuser (userRole,name,mobileNumber,email,password,address,status)values('Super Admin','SuperAdmin','12345','superadmin@testmail.com','admin','India','Active')");
            // st.executeUpdate("CREATE TABLE category (category_pk int AUTO_INCREMENT primary key,name varchar(200))");
            //  st.executeUpdate("CREATE TABLE product (product_pk int AUTO_INCREMENT primary key,name varchar(200),quantity int,price int,description varchar(500),category_fk int)");
            //    st.executeUpdate("CREATE TABLE customer (customer_pk int AUTO_INCREMENT primary key,name varchar(200),mobileNumber varchar(50),email varchar(200))");
            st.executeUpdate("CREATE TABLE orderDetails (order_pk int AUTO_INCREMENT primary key,orderId varchar(200),customer_fk int,orderDate varchar(200),totalPaid int)");
            JOptionPane.showMessageDialog(null, "Table Created successfully");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        } finally {
            try {
                con.close();
                st.close();
            } catch (Exception ex) {
            }
        }

    }

}
